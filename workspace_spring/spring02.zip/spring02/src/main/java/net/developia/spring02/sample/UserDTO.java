package net.developia.spring02.sample;

import lombok.Data;

@Data
public class UserDTO {
	private String usr_id;
	private String usr_name;
	private String usr_pw;
}
