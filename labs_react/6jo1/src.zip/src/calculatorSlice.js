import { createSlice } from '@reduxjs/toolkit';

const calculatorSlice = createSlice({
  name: 'calculator',
  initialState: 0,
  reducers: {
    add: (state, action) => state + action.payload,
    subtract: (state, action) => state - action.payload,
    multiply: (state, action) => state * action.payload,
    divide: (state, action) => state / action.payload,
    reset: () => 0,
  },
});

export const { add, subtract, multiply, divide, reset } = calculatorSlice.actions;

export default calculatorSlice.reducer;
