import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { add, subtract, multiply, divide, reset } from './calculatorSlice';

export default function App() {
  const [number, setNumber] = useState(1);
  const dispatch = useDispatch();
  const result = useSelector((state) => state);

  function changeNumber(event) {
    setNumber(Number(event.target.value));
  }

  function handleAdd() {
    dispatch(add(number));
  }

  function handleSubtract() {
    dispatch(subtract(number));
  }

  function handleMultiply() {
    dispatch(multiply(number));
  }

  function handleDivide() {
    dispatch(divide(number));
  }

  function handleReset() {
    dispatch(reset());
  }

  return (
    <div>
      <input type="text" value={number} onChange={changeNumber} />
      <button onClick={handleAdd}>더하기</button>
      <button onClick={handleSubtract}>빼기</button>
      <button onClick={handleMultiply}>곱하기</button>
      <button onClick={handleDivide}>나누기</button>
      <button onClick={handleReset}>초기화</button>
      <div>결과: {result}</div>
    </div>
  );
}
